import React from "react";

export default function Footer() {
  return (
    <>
      <div className="footer text-center">
        <h3>app for Tv showroom using React.</h3>
      </div>
    </>
  );
}
